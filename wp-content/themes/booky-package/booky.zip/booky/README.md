booky
===============================

For a detailed theme documentation: http://pankogut.com/wordpress-themes/booky

Support Forum: http://support.pankogut.com

===============================

Version 1.0
===============================
- booky theme release